import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profilebuilder2',
  templateUrl: './profilebuilder2.page.html',
  styleUrls: ['./profilebuilder2.page.scss'],
})
export class Profilebuilder2Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
