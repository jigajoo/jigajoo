import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profilebuilder3',
  templateUrl: './profilebuilder3.page.html',
  styleUrls: ['./profilebuilder3.page.scss'],
})
export class Profilebuilder3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
