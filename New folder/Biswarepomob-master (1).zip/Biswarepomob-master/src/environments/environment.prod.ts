export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyA3WxoUZGoaS-LQwmveyL0kliVXlxaLXWU",
    authDomain: "jigajoo-49fb4.firebaseapp.com",
    databaseURL: "https://jigajoo-49fb4.firebaseio.com",
    projectId: "jigajoo-49fb4",
    storageBucket: "jigajoo-49fb4.appspot.com",
    messagingSenderId: "146963155881",
    appId: "1:146963155881:web:5eb05f82f2dd0b5a4512b8",
    measurementId: "G-RSW96S5N1H"
  }
};
