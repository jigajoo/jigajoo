## Final Page:

Mappoint,
login,
signup,
setting,
signin,
profilereport
term of services
userranking
forgot password


## Api Integrated:(testing needed with real id):
 
 BlockUSer,
 insight(profileperformance),
 Ranking,


## Need Work:
messages,
matchcheckout
event
facebook login/splash page
subscription



## Design not completed
home,
message,
matchcheckout info div
myprofile


myprofile empty =>opening seting


Remain :
firebase
event 
subscription


## Discussion Pending

Edit profile
Feature
MAtch == home ???
profile image
sidemenu == home
userrating???






ionic plugin add cordova-plugin-facebook4 --variable APP_ID="494841734433175" --variable APP_NAME="Jigajoo"

ionic cordova plugin add cordova-plugin-facebook4 --variable APP_ID="494841734433175" --variable APP_NAME="Jigajoo"

ionic cordova plugin add cordova-plugin-facebook-connect --variable APP_ID="494841734433175" --variable APP_NAME="Jigajoo"